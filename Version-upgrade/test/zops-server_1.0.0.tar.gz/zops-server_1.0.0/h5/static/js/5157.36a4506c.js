/*!
 *  build: Vue  Admin Plus
 *  copyright: vue-admin-beautiful.com
 *  time: 2023-08-28 11:15:16
 */
"use strict";(self["webpackChunkadmin_plus"]=self["webpackChunkadmin_plus"]||[]).push([[5157,9527,9218],{79803:function(t,e,n){n.d(e,{Fh:function(){return u},ZC:function(){return c},cv:function(){return r},dW:function(){return i},i0:function(){return o},mY:function(){return d}});var a=n(52806);function r(t){return(0,a.Z)({params:{method:"problem.get",data:{selectAcknowledges:"extend",selectTags:"extend",selectSuppressionData:"extend",sortfield:"clock",sortorder:"DESC",...t}}})}function u(t){return(0,a.Z)({params:{method:"event.acknowledge",data:t}})}function o(t){return(0,a.Z)({params:{method:"action.create",data:t}})}function c(t){return(0,a.Z)({params:{method:"action.update",data:t}})}function d(t){return(0,a.Z)({params:{method:"action.get",data:t}})}function i(t){return(0,a.Z)({params:{method:"action.delete",data:t}})}}}]);