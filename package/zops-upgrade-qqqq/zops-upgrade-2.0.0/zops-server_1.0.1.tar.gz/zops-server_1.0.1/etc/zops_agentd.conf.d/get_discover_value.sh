
st_description=$(hostname)

# 获取序列号
serial_number=$(sudo dmidecode -s system-serial-number)

# 获取MAC地址
mac_addresses=$(ifconfig | grep -o -E '([0-9a-fA-F]{2}:){5}([0-9a-fA-F]{2})')

# 获取硬件型号
hardware_model=$(sudo dmidecode -s system-product-name)

json="["
counter=0
for mac_address in $mac_addresses; do
    counter=$((counter + 1))

    # 构建单个MAC地址的JSON对象
    mac_address_json="{ \"{#IFPHYSADDRESS}\": \"$mac_address\" }"

    # 添加到总的JSON对象中
    if [ $counter -eq 1 ]; then
        json="$json\n{ \"{#SYSDESC}\": \"$host_description\", \"{#IFPHYSADDRESS}\": \"$mac_address\", \"{#ENTPHYSICALSERIALNUM}\": \"$serial_number\", \"{#ENTPHYSICALMODELNAME}\": \"$hardware_model\" },"
    else
        json="$json\n$mac_address_json,"
    fi
done

# 移除最后一个逗号，添加结束括号
json="${json%?}\n]"

# 输出JSON对象
echo -e "$json"
